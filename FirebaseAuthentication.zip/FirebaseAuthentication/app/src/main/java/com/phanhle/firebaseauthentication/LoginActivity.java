package com.phanhle.firebaseauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //get view ref
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);

        //init firebase auth instance
        mAuth = FirebaseAuth.getInstance();
    }

    //region Event Handler methods
    public void signinEmailPassword(View view){
        if(!Helper.isOnline(this)){
            Toast.makeText(this, "Your device is not connected to Internet", Toast.LENGTH_SHORT).show();
            return;
        }
        if(!Helper.textLengthGreaterThan0(new Editable[] {etEmail.getText(), etPassword.getText()})) {
            Toast.makeText(this, "Please enter information first", Toast.LENGTH_SHORT).show();
            return;
        }

        //get user info
        String email, password;
        email = etEmail.getText().toString();
        password = etPassword.getText().toString();

        //signIn with firebase
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(//add callback action when completed signin
                        this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {//task do the signin action
                        if(task.isSuccessful()){//authentication result is successful
                            Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                            Helper.startActivity(LoginActivity.this, MainActivity.class);
                        }
                        else{//authentication is failed
                            Log.w("LoginActivity","createUserWithEmail:failure", task.getException());
                            Toast.makeText(LoginActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );
    }

    public void registerAccount(View view){
        Helper.startActivity(this, RegisterActivity.class);
    }
    //endregion

    //Views
    EditText etEmail, etPassword;

    //Firebase Authentication instance
    FirebaseAuth mAuth;


}
