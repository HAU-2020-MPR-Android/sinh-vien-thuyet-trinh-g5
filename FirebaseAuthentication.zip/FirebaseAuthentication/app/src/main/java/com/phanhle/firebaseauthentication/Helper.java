package com.phanhle.firebaseauthentication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.text.Editable;
import android.widget.EditText;

import androidx.core.app.ActivityCompat;

import java.util.List;

public class Helper {

    //start new activity
    public static void startActivity(Activity source, Class activityClass){
        source.startActivity(new Intent(source.getApplicationContext(), activityClass));
        source.finish();
    }

    //check internet connection
    public static boolean isOnline(Activity source){
        ConnectivityManager cm =
                (ConnectivityManager) source
                        .getApplicationContext()
                        .getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnectedOrConnecting();
    }

    //check string length
    public static boolean textLengthGreaterThan0(Editable[] textArray){
        for (Editable text : textArray){
            if(text.length() == 0)
                return false;
        }
        return true;
    }

}
