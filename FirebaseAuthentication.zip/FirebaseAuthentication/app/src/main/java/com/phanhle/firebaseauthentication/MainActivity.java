package com.phanhle.firebaseauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity implements FirebaseAuth.AuthStateListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //get view ref
        tvHello = findViewById(R.id.tv_hello);

        //get instance of firebase auth
        mAuth = FirebaseAuth.getInstance();
    }

    //region Event Handler methods
    @Override
    protected void onStart() {
        super.onStart();
//        change to user listener handler
//        FirebaseUser user = mAuth.getCurrentUser();
//        if(user == null){
//            startActivity(new Intent(MainActivity.this, LoginActivity.class));
//            finish();
//        }
        onAuthStateChanged(mAuth);
    }

    public void signout(View view){
        mAuth.signOut();
        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        finish();
    }

    //implement auth state listener, invoked when auth state is changed
    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        //get current user in firebase auth instance
        FirebaseUser user = mAuth.getCurrentUser();
        //if user is not authenticated, then make user login next
        if(user == null) {
//            change to use Helper static method
//            start LoginActitvity
//            startActivity(new Intent(getApplicationContext(), LoginActivity.class));
//            //execute onDestroy this MainActivity
//            finish();
            Helper.startActivity(this, LoginActivity.class);
        }
        else {
            username = user.getEmail();
            updateUI();
        }
    }

    void updateUI(){
        tvHello.setText("Hello user: "+username);
    }
    //endregion

    // firebase authentication instance
    FirebaseAuth mAuth;

    // listener for auth state change
    FirebaseAuth.AuthStateListener mAuthStateListener;

    // views
    TextView tvHello;

    // data
    String username;


}
