package com.phanhle.firebaseauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
    public final static String TAG = "Register";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //get view ref
        etEmail = findViewById(R.id.et_email_register);
        etPassword = findViewById(R.id.et_password_register);

        //init firebase auth instance
        mAuth = FirebaseAuth.getInstance();
    }

    //region Event Handler method
    public void createEmailPasswordAccount(View view){
        if(!Helper.isOnline(this)){
            Toast.makeText(this, "Your device is not connected to Internet", Toast.LENGTH_SHORT).show();
            return;
        }
        if(!Helper.textLengthGreaterThan0(new Editable[] {etEmail.getText(), etPassword.getText()})) {
            Toast.makeText(this, "Please enter information first", Toast.LENGTH_SHORT).show();
            return;
        }

        //get user info
        String email, password;
        email = etEmail.getText().toString();
        password = etPassword.getText().toString();

        //create new account
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(
                this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isComplete()){
                            Toast.makeText(RegisterActivity.this, "Register successful", Toast.LENGTH_SHORT).show();
                            Helper.startActivity(RegisterActivity.this, MainActivity.class);
                        }
                        else{
                            Toast.makeText(RegisterActivity.this, "Register failed", Toast.LENGTH_SHORT).show();
                            Log.w(TAG, "Authentication failed", task.getException());
                        }
                    }
                }
        );
    }

    public void signIn(View view){
        Helper.startActivity(this, LoginActivity.class);
    }
    //endregion

    //Views
    EditText etEmail, etPassword;

    //Firebase Authentication instance
    FirebaseAuth mAuth;
}
